// Client.cpp
#include <iostream>
#include <fstream>
#include <cstring>
#include <winsock2.h>

#define PORT 12345
#define BUFFER_SIZE 1024

int main()
{
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
    {
        std::cerr << "Error initializing Winsock\n";
        return -1;
    }

    SOCKET clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSocket == INVALID_SOCKET)
    {
        std::cerr << "Error creating socket\n";
        WSACleanup();
        return -1;
    }

    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(PORT);
    serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1"); // Replace with the server's IP address

    if (connect(clientSocket, reinterpret_cast<struct sockaddr *>(&serverAddr), sizeof(serverAddr)) == SOCKET_ERROR)
    {
        std::cerr << "Error connecting to server\n";
        closesocket(clientSocket);
        WSACleanup();
        return -1;
    }

    // Receive Hello message
    char helloBuffer[BUFFER_SIZE];
    recv(clientSocket, helloBuffer, sizeof(helloBuffer), 0);
    std::cout << "Server says: " << helloBuffer << std::endl;

    // File transfer
    std::ofstream receivedFile("received_file.txt", std::ios::binary);

    char fileBuffer[BUFFER_SIZE];
    int bytesRead;
    while ((bytesRead = recv(clientSocket, fileBuffer, sizeof(fileBuffer), 0)) > 0)
    {
        receivedFile.write(fileBuffer, bytesRead);
    }

    std::cout << "File received successfully\n";

    // Close socket
    closesocket(clientSocket);
    WSACleanup();

    return 0;
}
