// Server.cpp
#include <iostream>
#include <fstream>
#include <cstring>
#include <winsock2.h>

#define PORT 12345
#define BUFFER_SIZE 1024

int main()
{
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
    {
        std::cerr << "Error initializing Winsock\n";
        return -1;
    }

    SOCKET serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == INVALID_SOCKET)
    {
        std::cerr << "Error creating socket\n";
        WSACleanup();
        return -1;
    }

    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(PORT);
    serverAddr.sin_addr.s_addr = INADDR_ANY;

    if (bind(serverSocket, reinterpret_cast<struct sockaddr *>(&serverAddr), sizeof(serverAddr)) == SOCKET_ERROR)
    {
        std::cerr << "Error binding socket\n";
        closesocket(serverSocket);
        WSACleanup();
        return -1;
    }

    if (listen(serverSocket, 5) == SOCKET_ERROR)
    {
        std::cerr << "Error listening on socket\n";
        closesocket(serverSocket);
        WSACleanup();
        return -1;
    }

    std::cout << "Server listening on port " << PORT << std::endl;

    SOCKET clientSocket = accept(serverSocket, nullptr, nullptr);
    if (clientSocket == INVALID_SOCKET)
    {
        std::cerr << "Error accepting connection\n";
        closesocket(serverSocket);
        WSACleanup();
        return -1;
    }

    // Say Hello
    const char helloMessage[] = "Hello from server!";
    send(clientSocket, helloMessage, strlen(helloMessage), 0);
    std::cout << "Hello message sent to client\n";

    // File transfer
    std::ifstream file("example.txt", std::ios::binary);
    if (!file.is_open())
    {
        std::cerr << "Error opening file\n";
        closesocket(clientSocket);
        closesocket(serverSocket);
        WSACleanup();
        return -1;
    }

    char buffer[BUFFER_SIZE];
    while (!file.eof())
    {
        file.read(buffer, sizeof(buffer));
        send(clientSocket, buffer, static_cast<int>(file.gcount()), 0);
    }

    std::cout << "File sent successfully\n";

    // Close sockets
    closesocket(clientSocket);
    closesocket(serverSocket);
    WSACleanup();

    return 0;
}
