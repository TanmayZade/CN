#include <iostream>
#include <cstdint>
#include <winsock2.h>

// IP Header Structure
struct IPHeader
{
    uint8_t versionIHL;
    uint8_t dscpECN;
    uint16_t totalLength;
    uint16_t identification;
    uint16_t flagsFragmentOffset;
    uint8_t timeToLive;
    uint8_t protocol;
    uint16_t headerChecksum;
    in_addr sourceIP; // Use in_addr for IPv4 address
    in_addr destIP;   // Use in_addr for IPv4 address
};

// TCP Header Structure
struct TCPHeader
{
    uint16_t sourcePort;
    uint16_t destPort;
    uint32_t sequenceNumber;
    uint32_t acknowledgmentNumber;
    uint8_t dataOffsetReservedFlags;
    uint16_t windowSize;
    uint16_t checksum;
    uint16_t urgentPointer;
};

void analyzeIPPacket(const uint8_t *packet)
{
    const IPHeader *ipHeader = reinterpret_cast<const IPHeader *>(packet);

    std::cout << "IP Header Analysis:" << std::endl;
    std::cout << "Source IP: " << inet_ntoa(ipHeader->sourceIP) << std::endl;
    std::cout << "Destination IP: " << inet_ntoa(ipHeader->destIP) << std::endl;
    std::cout << "Protocol: " << static_cast<int>(ipHeader->protocol) << std::endl;
    std::cout << std::endl;
}

void analyzeTCPPacket(const uint8_t *packet)
{
    const TCPHeader *tcpHeader = reinterpret_cast<const TCPHeader *>(packet + sizeof(IPHeader));

    std::cout << "TCP Header Analysis:" << std::endl;
    std::cout << "Source Port: " << ntohs(tcpHeader->sourcePort) << std::endl;
    std::cout << "Destination Port: " << ntohs(tcpHeader->destPort) << std::endl;
    std::cout << "Sequence Number: " << ntohl(tcpHeader->sequenceNumber) << std::endl;
    std::cout << "Acknowledgment Number: " << ntohl(tcpHeader->acknowledgmentNumber) << std::endl;
    std::cout << "Window Size: " << ntohs(tcpHeader->windowSize) << std::endl;
    std::cout << "Checksum: " << ntohs(tcpHeader->checksum) << std::endl;
    std::cout << std::endl;
}

int main()
{
    // Initialize Winsock
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
    {
        std::cerr << "Error initializing Winsock" << std::endl;
        return -1;
    }

    // Simulated packet data (replace with actual packet data)
    const uint8_t packetData[] = {
        // IP Header
        0x45,
        0x00,
        0x00,
        0x34,
        0x12,
        0x34,
        0x40,
        0x00,
        0x40,
        0x06,
        0x00,
        0x00,
        0xC0,
        0xA8,
        0x01,
        0x01,
        0xC0,
        0xA8,
        0x01,
        0x02,

        // TCP Header
        0x00,
        0x50,
        0x00,
        0x50,
        0x00,
        0x00,
        0x00,
        0x00,
        0x80,
        0x02,
        0xFF,
        0xFF,
        0x00,
        0x00,
        0x02,
        0x04,
        0x05,
        0xB4,
        0x01,
        0x03,
        0x03,
        0x08,
    };

    // Analyze IP Packet
    analyzeIPPacket(packetData);

    // Analyze TCP Packet
    analyzeTCPPacket(packetData);

    // Cleanup Winsock
    WSACleanup();

    return 0;
}
