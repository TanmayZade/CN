#include <iostream>
#include <cmath>
#include <winsock2.h>

#pragma comment(lib, "ws2_32.lib")

double performArithmeticOperation(double operand1, double operand2, char operation)
{
    switch (operation)
    {
    case '+':
        return operand1 + operand2;
    case '-':
        return operand1 - operand2;
    case '*':
        return operand1 * operand2;
    case '/':
        if (operand2 != 0)
        {
            return operand1 / operand2;
        }
        else
        {
            return NAN; // Indicate division by zero
        }
    default:
        return NAN; // Invalid operation
    }
}

double performTrigonometryOperation(double operand, char operation)
{
    switch (operation)
    {
    case 's':
        return sin(operand);
    case 'c':
        return cos(operand);
    case 't':
        return tan(operand);
    default:
        return NAN; // Invalid operation
    }
}

int main()
{
    // Initialize Winsock
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
    {
        std::cerr << "Error initializing Winsock" << std::endl;
        return -1;
    }

    // Create a socket
    SOCKET serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == INVALID_SOCKET)
    {
        std::cerr << "Error creating socket" << std::endl;
        WSACleanup();
        return -1;
    }

    // Set up server address information
    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(12345); // Choose any available port
    serverAddr.sin_addr.s_addr = INADDR_ANY;

    // Bind the socket
    if (bind(serverSocket, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR)
    {
        std::cerr << "Error binding socket" << std::endl;
        closesocket(serverSocket);
        WSACleanup();
        return -1;
    }

    // Listen for incoming connections
    if (listen(serverSocket, 5) == SOCKET_ERROR)
    {
        std::cerr << "Error listening for connections" << std::endl;
        closesocket(serverSocket);
        WSACleanup();
        return -1;
    }

    std::cout << "Server listening on port 12345..." << std::endl;

    // Accept a connection
    SOCKET clientSocket = accept(serverSocket, nullptr, nullptr);
    if (clientSocket == INVALID_SOCKET)
    {
        std::cerr << "Error accepting connection" << std::endl;
        closesocket(serverSocket);
        WSACleanup();
        return -1;
    }

    // Receive operation type (arithmetic or trigonometry)
    char operationType;
    recv(clientSocket, &operationType, sizeof(operationType), 0);

    // Receive operands and operator
    double operand1, operand2;
    char operation;
    recv(clientSocket, reinterpret_cast<char *>(&operand1), sizeof(operand1), 0);
    recv(clientSocket, &operation, sizeof(operation), 0);

    if (operationType == 'a')
    {
        recv(clientSocket, reinterpret_cast<char *>(&operand2), sizeof(operand2), 0);

        // Perform arithmetic operation
        double result = performArithmeticOperation(operand1, operand2, operation);

        // Send the result back to the client
        send(clientSocket, reinterpret_cast<char *>(&result), sizeof(result), 0);
    }
    else if (operationType == 't')
    {
        // Perform trigonometry operation
        double result = performTrigonometryOperation(operand1, operation);

        // Send the result back to the client
        send(clientSocket, reinterpret_cast<char *>(&result), sizeof(result), 0);
    }
    else
    {
        // Invalid operation type
        std::cerr << "Invalid operation type" << std::endl;
    }

    // Close sockets
    closesocket(clientSocket);
    closesocket(serverSocket);
    WSACleanup();

    return 0;
}
