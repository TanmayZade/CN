#include <iostream>
#include <winsock2.h>

#pragma comment(lib, "ws2_32.lib")

int main()
{
    // Initialize Winsock
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
    {
        std::cerr << "Error initializing Winsock" << std::endl;
        return -1;
    }

    // Create a socket
    SOCKET clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSocket == INVALID_SOCKET)
    {
        std::cerr << "Error creating socket" << std::endl;
        WSACleanup();
        return -1;
    }

    // Set up server address information
    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(12345);                  // Use the same port as the server
    serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1"); // Use the server's IP address

    // Connect to the server
    if (connect(clientSocket, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR)
    {
        std::cerr << "Error connecting to server" << std::endl;
        closesocket(clientSocket);
        WSACleanup();
        return -1;
    }

    // Choose operation type (arithmetic or trigonometry)
    char operationType;
    std::cout << "Choose operation type (a for arithmetic, t for trigonometry): ";
    std::cin >> operationType;

    // Send operation type to the server
    send(clientSocket, &operationType, sizeof(operationType), 0);

    // Send operands and operator to the server
    double operand1, operand2;
    char operation;
    std::cout << "Enter operand 1: ";
    std::cin >> operand1;
    std::cout << "Enter operation: ";
    std::cin >> operation;

    send(clientSocket, reinterpret_cast<char *>(&operand1), sizeof(operand1), 0);
    send(clientSocket, &operation, sizeof(operation), 0);

    if (operationType == 'a')
    {
        std::cout << "Enter operand 2: ";
        std::cin >> operand2;

        send(clientSocket, reinterpret_cast<char *>(&operand2), sizeof(operand2), 0);

        // Receive and display the result from the server
        double result;
        recv(clientSocket, reinterpret_cast<char *>(&result), sizeof(result), 0);
        std::cout << "Result: " << result << std::endl;
    }
    else if (operationType == 't')
    {
        // Receive and display the result from the server
        double result;
        recv(clientSocket, reinterpret_cast<char *>(&result), sizeof(result), 0);
        std::cout << "Result: " << result << std::endl;
    }
    else
    {
        // Invalid operation type
        std::cerr << "Invalid operation type" << std::endl;
    }

    // Close the socket
    closesocket(clientSocket);
    WSACleanup();

    return 0;
}
