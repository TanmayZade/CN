#include <iostream>
#include <fstream>
#include <winsock2.h>

#pragma comment(lib, "ws2_32.lib")

void receiveFile(const char *filename, SOCKET socket)
{
    std::ofstream file(filename, std::ios::out | std::ios::binary);
    if (!file.is_open())
    {
        std::cerr << "Error opening file for writing: " << filename << std::endl;
        return;
    }

    char buffer[1024];
    int bytesRead;

    do
    {
        bytesRead = recv(socket, buffer, sizeof(buffer), 0);
        if (bytesRead > 0)
        {
            file.write(buffer, bytesRead);
        }
    } while (bytesRead > 0);

    file.close();
    std::cout << "File received: " << filename << std::endl;
}

int main()
{
    // Initialize Winsock
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
    {
        std::cerr << "Error initializing Winsock" << std::endl;
        return -1;
    }

    // Create a UDP socket
    SOCKET serverSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (serverSocket == INVALID_SOCKET)
    {
        std::cerr << "Error creating socket" << std::endl;
        WSACleanup();
        return -1;
    }

    // Set up server address information
    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(12345); // Choose any available port
    serverAddr.sin_addr.s_addr = INADDR_ANY;

    // Bind the socket
    if (bind(serverSocket, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR)
    {
        std::cerr << "Error binding socket" << std::endl;
        closesocket(serverSocket);
        WSACleanup();
        return -1;
    }

    std::cout << "Server listening on port 12345..." << std::endl;

    // Receive script file
    receiveFile("received_script.txt", serverSocket);

    // Receive text file
    receiveFile("received_text.txt", serverSocket);

    // Receive audio file
    receiveFile("received_audio.wav", serverSocket);

    // Receive video file
    receiveFile("received_video.mp4", serverSocket);

    // Close socket
    closesocket(serverSocket);
    WSACleanup();

    return 0;
}
