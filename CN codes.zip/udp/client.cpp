#include <iostream>
#include <fstream>
#include <winsock2.h>

#pragma comment(lib, "ws2_32.lib")

void sendFile(const char *filename, SOCKET socket)
{
    std::ifstream file(filename, std::ios::in | std::ios::binary);
    if (!file.is_open())
    {
        std::cerr << "Error opening file for reading: " << filename << std::endl;
        return;
    }

    char buffer[1024];
    int bytesRead;

    do
    {
        file.read(buffer, sizeof(buffer));
        bytesRead = static_cast<int>(file.gcount());

        if (bytesRead > 0)
        {
            send(socket, buffer, bytesRead, 0);
        }
    } while (bytesRead > 0);

    file.close();
    std::cout << "File sent: " << filename << std::endl;
}

int main()
{
    // Initialize Winsock
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
    {
        std::cerr << "Error initializing Winsock" << std::endl;
        return -1;
    }

    // Create a UDP socket
    SOCKET clientSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (clientSocket == INVALID_SOCKET)
    {
        std::cerr << "Error creating socket" << std::endl;
        WSACleanup();
        return -1;
    }

    // Set up server address information
    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(12345);                  // Use the same port as the server
    serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1"); // Use the server's IP address

    // Send script file
    sendFile("script.txt", clientSocket);

    // Send text file
    sendFile("text.txt", clientSocket);

    // Send audio file
    sendFile("audio.wav", clientSocket);

    // Send video file
    sendFile("video.mp4", clientSocket);

    // Close socket
    closesocket(clientSocket);
    WSACleanup();

    return 0;
}
