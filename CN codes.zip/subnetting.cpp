#include <iostream>
#include <cmath>
#include <bitset>

using namespace std;

// Function to calculate subnet mask based on prefix length
string calculateSubnetMask(int prefixLength)
{
    // Validate prefix length
    if (prefixLength < 0 || prefixLength > 32)
    {
        cerr << "Invalid prefix length. It should be between 0 and 32." << endl;
        exit(1);
    }

    // Calculate subnet mask
    int fullOctets = prefixLength / 8;
    int remainingBits = prefixLength % 8;

    // Create subnet mask
    string subnetMask = "";
    for (int i = 0; i < fullOctets; ++i)
    {
        subnetMask += "11111111.";
    }

    if (remainingBits > 0)
    {
        int remainingOctet = pow(2, 8 - remainingBits) - 1;
        subnetMask += bitset<8>(remainingOctet).to_string();
    }
    else
    {
        subnetMask += "00000000";
    }

    return subnetMask;
}

int main()
{
    // Input IP address and prefix length
    string ipAddress;
    int prefixLength;

    cout << "Enter IP address (e.g., 192.168.1.1): ";
    cin >> ipAddress;

    cout << "Enter prefix length (e.g., 24): ";
    cin >> prefixLength;

    // Calculate and display subnet mask
    string subnetMask = calculateSubnetMask(prefixLength);
    cout << "Subnet Mask: " << subnetMask << endl;

    return 0;
}
