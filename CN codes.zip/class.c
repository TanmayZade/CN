#include <stdio.h>
#include <string.h>

int main()
{
    char ip[16]; // Assuming IPv4 address, e.g., "192.168.1.1"
    printf("Enter IP address: ");
    scanf("%s", ip);

    // Tokenizing the IP address
    char *token = strtok(ip, ".");
    int firstOctet = atoi(token);

    // Determine the class
    char ipClass;
    if (firstOctet >= 1 && firstOctet <= 126)
        ipClass = 'A';
    else if (firstOctet >= 128 && firstOctet <= 191)
        ipClass = 'B';
    else if (firstOctet >= 192 && firstOctet <= 223)
        ipClass = 'C';
    else if (firstOctet >= 224 && firstOctet <= 239)
        ipClass = 'D';
    else if (firstOctet >= 240 && firstOctet <= 255)
        ipClass = 'E';
    else
    {
        printf("Invalid IP address\n");
        return 1; // Exit with an error code
    }

    // Print the result
    printf("IP Class: %c\n", ipClass);

    return 0; // Exit successfully
}
