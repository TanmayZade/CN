#include <iostream>
#include <limits.h>
#include <vector>

class Graph
{
private:
    int vertices;
    std::vector<std::vector<int>> adjacencyMatrix;

public:
    Graph(int v) : vertices(v), adjacencyMatrix(v, std::vector<int>(v, INT_MAX)) {}

    void addEdge(int src, int dest, int weight)
    {
        adjacencyMatrix[src][dest] = weight;
        adjacencyMatrix[dest][src] = weight; // Assuming an undirected graph
    }

    int minDistance(const std::vector<int> &dist, const std::vector<bool> &sptSet)
    {
        int min = INT_MAX, minIndex = -1;

        for (int v = 0; v < vertices; ++v)
        {
            if (!sptSet[v] && dist[v] <= min)
            {
                min = dist[v];
                minIndex = v;
            }
        }

        return minIndex;
    }

    void printSolution(const std::vector<int> &dist)
    {
        std::cout << "Vertex \t Distance from Source\n";
        for (int i = 0; i < vertices; ++i)
            std::cout << i << " \t " << dist[i] << std::endl;
    }

    void dijkstra(int src)
    {
        std::vector<int> dist(vertices, INT_MAX);
        std::vector<bool> sptSet(vertices, false);

        dist[src] = 0;

        for (int count = 0; count < vertices - 1; ++count)
        {
            int u = minDistance(dist, sptSet);
            sptSet[u] = true;

            for (int v = 0; v < vertices; ++v)
            {
                if (!sptSet[v] && adjacencyMatrix[u][v] != INT_MAX &&
                    dist[u] != INT_MAX && dist[u] + adjacencyMatrix[u][v] < dist[v])
                {
                    dist[v] = dist[u] + adjacencyMatrix[u][v];
                }
            }
        }

        printSolution(dist);
    }
};

int main()
{
    // Create a graph with 5 vertices
    Graph g(5);

    // Add edges with weights
    g.addEdge(0, 1, 2);
    g.addEdge(0, 2, 4);
    g.addEdge(1, 2, 1);
    g.addEdge(1, 3, 7);
    g.addEdge(2, 4, 3);
    g.addEdge(3, 4, 1);

    // Run Dijkstra's algorithm with source node 0
    g.dijkstra(0);

    return 0;
}
